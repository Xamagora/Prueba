/**
 *  This class is the main class of the "World of Zuul" application. 
 *  "World of Zuul" is a very simple, text based adventure game.  Users 
 *  can walk around some scenery. That's all. It should really be extended 
 *  to make it more interesting!
 * 
 *  To play this game, create an instance of this class and call the "play"
 *  method.
 * 
 *  This main class creates and initialises all the others: it creates all
 *  rooms, creates the parser and starts the game.  It also evaluates and
 *  executes the commands that the parser returns.
 * 
 * @author  Michael Kolling and David J. Barnes
 * @version 1.0 (February 2002)
 */

public class Game 
{
    private Parser parser;
    private Player player;
    private Room estacion, armas, cementerio, barra, selago, pacorta, seller, barbaño, confesionario, hospital,homorgue, homiriam, miriam, mirecamara, mibaño, micocina, misala, mizotano, miatico, bar, lago, iglesia, zocalo, out1, out2, out3, out4, out5, out6, out7, out8;
        
    /**
     * Create the game and initialise its internal map.
     */
    public Game() 
    {                
        Room startRoom = createRooms();
        player = new Player("Zaphod", startRoom);        
        parser = new Parser();
    }

    /**
     * Create all the rooms and link their exits together.
     * 
     * @return Returns the starting room
     */
    private Room createRooms()
    {
      
        // create the rooms
        estacion = new Room("en la estación de policia, ve al hospital");
        armas = new Room("en la tienda de armas más particular de la región");
        seller = new Room("estas en la caja de la armeria, ve hacia ese pasillo");
        pacorta = new Room("pasillo de arma corta, han asesinado al vendedor, sal de ahí. Ve al lago, quiza ese hombre lamato pero ya lo sabre");
        cementerio = new Room("en el escalofriante cementerio de Rocket");
        hospital = new Room("en el lobby del hospital, investiga");
        miriam= new Room("en el cuarto principal de la casa de Miriam donde fue asesinada");
        bar = new Room("en la pista de baile rústico bar del pueblo");
        barra = new Room("en la barra de este paradisiaco lugar");
        barbaño = new Room("en el baño público más limpio del mundo");
        lago = new Room("enfrente del lago con sus rumores antiguos, no saltes al lago puedes morir");
        selago = new Room("en el fondo del lago");
        iglesia = new Room("en la entrada de la moumental iglesia donde los feligreses alaban");
        confesionario = new Room ("Lugar donde los humanos se libra del pecado, esta cura siempre");
        zocalo = new Room("en la solitaria zocalo");
        out1 = new Room("en la avenida Legaria");
        out2 = new Room("en la avenida Rosas ");
        out3 = new Room("en la avenida Zedillo");
        out4 = new Room("en la avenida Misterios");
        out5 = new Room("en la avenida Calandrias ");
        out6 = new Room("en la avenida Nilo ");
        out7 = new Room("en la avenida Jamzin ");
        out8 = new Room("en la avenida Constitución");
        mibaño= new Room("en el baño, un lugar muy sospechoso. Espera que hay arriba, un pasadiso");
        mirecamara= new Room("en la recamara, parece que fue amarrada a la cama y violada. ¡Pobre mujer!");
        micocina= new Room("en la cocina, segun su asesino agarro un cuchillo y la mato a sangre fria");
        misala= new Room("en sala, donde hay una puerta");
        miatico = new Room ("en el zotano, has prendido tu lampara");
        mizotano= new Room("en este zotano es en donde esta una caja con las fotos en la que la persona que la mato. Eres tú");
        homorgue = new Room ("en la morgue del hospistal, busca a tu alrededor");
        homiriam = new Room ("en el cuarto 210, De jesús, dicen que fue golpeado ese mismo día pero murió Miriam, ve a tu alredor.");
        
        
        
        
     
        // put items in the room
        mizotano.addItem(new Item ( "fotografias", "fotografias de ti matando a Miriam", 0.1));
        pacorta.addItem(new Item("escopeta", "Una escopeta ", 7.50));
        pacorta.addItem(new Item("rifle", "Una rifle con sileciador ", 10.50));
        pacorta.addItem(new Item("pistola", "Una pistola ", 2.50));
        seller.addItem( new Item("vendedor", "Yo vi como llevaba un cuerpo al lago, parecía un bebe, ese hombre es un demente", 500));
        homorgue.addItem( new Item("bisturi", "un bisturi sobre una mesa con un corazón a un lado", 1.3));
        barra.addItem(new Item("cerveza", "Cerveza, ", 0.50));
        barra.addItem(new Item("margarita", "Margarita,", 0.50));
        barra.addItem(new Item("vino", "Vino blanco", 0.50));
        armas.addItem(new Item("identificación", "una identificación mía", 0.01));
        barbaño.addItem(new Item("Viejo con pistola", "Sal de aqui si no quieres que te dispare, no lo volvere hacer de nuevo, si quieres respuestas ve con él por una arma", 100));
        bar.addItem(new Item("Dueño del bar", "Él llego muy drogado, bebió unas cervezas y se fue al mismo tiempo que Jesus y Miriam, le escuche decir algo de arma", 0.5));
        confesionario.addItem(new Item("Cura", "Jesús me confeso que amaba a Miriam pero esa noche en el bar él la siguó", 1000));
        homiriam.addItem(new Item("carta", "Esta carta es para confesar que yo amaba pero le prometí a él que no diría nada, solo se lo dije al cura", 0.5));
        zocalo.addItem(new Item("Peridico", "En pasado 28 de mayo, fue asesinada Miriam, su asesino sigue profugo", 100));
        selago.addItem(new Item("key", "una llave que habre el zotano de la casa de Miriam", 0.01));
        
        
        
        // create a key that will be used to lock the door to the office
        
        Item key = new Item("key", "una llave que habre el zotano de la casa de Miriam", 0.01);
        selago.addItem(key);
        
        
        // initialise room exits
        
        new Door(estacion, "legaria", out1, "estacion", null);
        
        new Door(armas, "constitucion", out8, "armas", null);
        new Door(armas, "caja", seller, "armas", null);
        new Door(seller, "armas", armas, "caja", null);
        new Door(seller, "pasillo" , pacorta, "", null);
        new Door(pacorta, "salir" , out8, "", null);
        
       
        
        new Door(out8, "armas", armas,"constitucion", null);
        new Door(out8, "legaria", out1, "constitucion", null);
        new Door(out8, "jazmin", out7, "constitucion", null);
        
        new Door(out1, "constitucion", out8, "legaria", null);
        new Door(out1, "rosas", out2, "legaria", null);
        new Door(out1, "estacion", estacion, "legaria", null);
        new Door(out1, "zocalo", zocalo, "legaria", null);
        
        new Door(out2, "legaria", out1, "rosas", null);
        new Door(out2, "iglesia", iglesia, "rosas", null);
        new Door(out2, "zedillo", out3, "rosas", null);
        
        new Door(iglesia, "rosas", out2, "iglesia", null);
        new Door(iglesia, "confesionario", confesionario, "iglesia", null);
        
        new Door(confesionario, "", iglesia, "iglesia", null);
        
        new Door(cementerio, "jazmin", out7, "cementerio", null);
        
        new Door(out7, "zocalo", zocalo, "jazmin", null);
        new Door(out7, "cementerio", cementerio, "jazmin", null);
        new Door(out7, "nilo", out6, "jazmin", null);
        new Door(out7, "constitucion", out8, "jazmin", null);
        
        new Door(zocalo, "legaria", out1, "zocalo", null);
        new Door(zocalo, "calandrias", out5, "zocalo", null);
        new Door(zocalo, "jazmin", out7, "zocalo", null);
        new Door(zocalo, "zedillo", out3, "zocalo", null);
        
        new Door(out3, "lago", lago, "zedillo", null);
        new Door(out3, "zocalo", zocalo, "zedillo", null);
        new Door(out3, "rosas", out2, "zedillo", null);
        new Door(out3, "misterios", out4, "zedillo", null);
        
        new Door(lago, "zedillo", out3, "lago", null);
        new Door(lago, "lagoin", selago, "lago", null);
        new Door(selago, "lago", lago, "", null);

        
        new Door(out6, "north", out7, "south", null);
        new Door(out6, "west", out5, "east", null);
        new Door(out6, "east", hospital, "west", null);
        
        new Door(out5, "zocalo", zocalo, "calandrias", null);
        new Door(out5, "misterios", out4, "calandrias", null);
        new Door(out5, "nilo", out6, "calandrias", null);
        new Door(out5, "casa", miriam, "calandrias", null);
        
        new Door(out4, "zedillo", out3, "misterios", null);
        new Door(out4, "calandrias", out5 , "misterios", null);
        new Door(out4, "bar", bar, "misterios", null);
        
        new Door(bar, "misterios", out4, "bar", null);
        new Door(bar, "barra", barra, "bar", null);
        
        new Door(barra, "baño", barbaño, "barra", null);
        new Door(barra, "bar", bar, "barra", null);
        
        new Door(barbaño, "barra",barra, "", null);
      
        new Door(miriam, "calandrias", out5, "casa", null);
        new Door(miriam, "sala", misala, "casa", null);
        new Door(miriam, "recamara", mirecamara, "casa", null);
        new Door(misala, "cocina", micocina, "sala", null);
        new Door(misala, "casa", miriam, "sala", null);
        new Door(misala, "zotano", mizotano, "", null);
        new Door(mibaño, "recamara", mirecamara, "baño", null);
        new Door(mibaño, "atico", miatico, "baño", null);
        new Door(miatico, "baño", mibaño, "", null);
        new Door(mirecamara, "cocina", micocina, "recamara", null);
        new Door(mirecamara, "baño", mibaño,"recamara", null);
        new Door(mirecamara, "casa", miriam,"recamara", null);
        new Door(mizotano, "sala", misala, "", key);
        new Door(micocina, "east", mirecamara, "cocina", null);
        new Door(micocina, "sala", misala, "cocina", null);
        
        new Door(hospital, "nilo", out6, "hospital", null);
        new Door(hospital, "morgue", homorgue, "hospital", null);
        new Door(hospital, "cuarto", homiriam, "hospital", null); 
        new Door(homorgue, "hospital", hospital, "", null);
        new Door(homiriam, "hospital", hospital, "", null); 
      
        
       
        
        
        
        
        
        
        

        return estacion;
    }

    /**
     *  Main play routine.  Loops until end of play.
     */
    public void play() 
    {            
        printWelcome();

        // Enter the main command loop.  Here we repeatedly read commands and
        // execute them until the game is over.
                
        boolean finished = false;
        while (! finished) {
            Command command = parser.getCommand();
            finished = processCommand(command);
            if(player.isDead()) {
                printDead();
                finished = true;
            }
            if(player.getCurrentRoom() == mizotano) {
                printVictory();
                finished = true;
            }
        }
        System.out.println("Gracias por intentarlo.  Éxito en tu vida normal.");
    }

    /**
     * Print out the opening message for the player.
     */
    private void printWelcome()
    {
        System.out.println();
        System.out.println("Welcome to Rockect Village!");
        System.out.println("Donde jugarás el papel de un ingenioso dectective que su objetivo es conocer a la persona ");
        System.out.println("que cometió el asesinato de Miriam Chemil. Encuentra la llave. Desafía a tus sentidos. ");
        System.out.println();
        System.out.println(player.getLongDescription());
    }
    
    private void printDead() {
        System.out.println("\n Perdiste.");
    }
    
    private void printVictory() {
        System.out.println("\n Ganaste. Bien hecho IQ 20!");
    }
    
    
    /**
     * Given a command, process (that is: execute) the command.
     * If this command ends the game, true is returned, otherwise false is
     * returned.
     */
    private boolean processCommand(Command command) 
    {
        boolean wantToQuit = false;

        if(command.isUnknown()) {
            System.out.println("No se a que te refieres...");
            return false;
        }

        String commandWord = command.getCommandWord();
        if (commandWord.equals("help"))
            printHelp();
        else if (commandWord.equals("go"))
            goRoom(command);
        else if (commandWord.equals("quit")) {
            wantToQuit = quit(command);
        } 
        else if (commandWord.equals("take")) {
            take(command);
        }
        else if (commandWord.equals("drop")) {
            drop(command);
        }        
        else if (commandWord.equals("items")) {
            printItems();
        }
        else if (commandWord.equals("drink")) {
            eat(command);
        }
       
        
        return wantToQuit;
    }

    // implementations of user commands:

    /**
     * Print out some help information.
     * Here we print some stupid, cryptic message and a list of the 
     * command words.
     */
    private void printHelp() 
    {
        System.out.println("Estas perdido. Obten unas pistas. Talvéz te ayuden en tu travesía");
        System.out.println("en Rockect Village");
        System.out.println();
        System.out.println("Tus comandos son los siguientes:");
        parser.showCommands();
    }

    /** 
     * Try to go to one direction. If there is an exit, enter the new
     * room, otherwise print an error message.
     */
    private void goRoom(Command command) 
    {
        if(!command.hasSecondWord()) {
            // if there is no second word, we don't know where to go...
            System.out.println("Go where?");
            return;
        }

        String direction = command.getSecondWord();

        // Try to leave current room.
        Door door = player.getCurrentRoom().getDoor(direction);

        if (door == null)
            System.out.println("There is no door!");
        else {
            if(player.goThrough(direction)) {
                System.out.println(player.getLongDescription());
            } else {
                System.out.println("The door is locked and you don't have the key for it");
            }
       }
    }

    /** 
     * "Quit" was entered. Check the rest of the command to see
     * whether we really quit the game. Return true, if this command
     * quits the game, false otherwise.
     */
    private boolean quit(Command command) 
    {
        if(command.hasSecondWord()) {
            System.out.println("Quit what?");
            return false;
        }
        else
            return true;  // signal that we want to quit
    }
    
    /** 
     * Try to take an item from the current room. If the item is there,
     * pick it up, if not print an error message.
     */
    private void take(Command command) 
    {
        if(!command.hasSecondWord()) {
            // if there is no second word, we don't know what to take...
            System.out.println("What do you want to take?");
            return;
        }

        String itemName = command.getSecondWord();
        Item item = player.pickUpItem(itemName);
        
        if(item == null) {
            System.out.println("Can't pick up the item: " + itemName);
        } else {
            System.out.println("Picked up " + item.getDescription());
        }
    }
    
    /** 
     * Drops an item into the current room. If the player carries the item
     * drop it, if not print an error message.
     */
    private void drop(Command command) 
    {
        if(!command.hasSecondWord()) {
            // if there is no second word, we don't know what to drop...
            System.out.println("What do you want to drop?");
            return;
        }

        String itemName = command.getSecondWord();
        Item item = player.dropItem(itemName);
        
        if(item == null) {
            System.out.println("You don't carry the item: " + itemName);
        } else {
            System.out.println("Dropped " + item.getDescription());
        }
    }
    
    /**
     * Prints out the items that the player is currently carrying.
     */
    private void printItems() {
        System.out.println(player.getItemsString());   
    }
    
     /** 
     * Try to take an item from the current room. If the item is there,
     * pick it up, if not print an error message.
     */
    private void eat(Command command) 
    {
        if(!command.hasSecondWord()) {
            // if there is no second word, we don't know what to eat...
            System.out.println("What do you want to drink?");
            return;
        }
        String itemName = command.getSecondWord();
        Item item = player.eat(itemName);
        if(item == null) {
            System.out.println("Could not drink " + itemName);            
        } 
        else {
            System.out.println("Drunk " + item.getDescription());
        }
    }
    
 
}