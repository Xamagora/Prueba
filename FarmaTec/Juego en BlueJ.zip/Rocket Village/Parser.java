import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

/*
 * Esta clase es parte de Rocket Village.
 * Es una aventura de un detective famoso que buscará al culpable de un asesinato. 
 *
 * Este parser lee las entradas e intenta interpretarlas como comandos de aventura
 * Todo el tiempo que se es convocado este leerá la linea de la temrinal y tratará de intrepetar
 * la segunda palabra comando. Regresará el comando como un objeto a la clase Comando.
 * 
 * El parser tiene una base de palabras comando conocidas. Se checará las entradas del usuario
 * contra los comandos conocidos, y sila entrdada no esta, este regresará que la palabraa 
 * no es conocida.
 * 
 * @author  Quiroz Bonilla Gabriel Alejandro
 * @version 1.0 
 */

public class Parser 
{

    private CommandWords commands;  // Contiene todas las palabras comando válidas.

    public Parser() 
    {
        commands = new CommandWords();
    }

    public Command getCommand() 
    {
        String inputLine = "";   // Sostendrá la línea completa de la entrada.
        String word1;
        String word2;

        System.out.print("> ");     // Imprime 

        BufferedReader reader = 
            new BufferedReader(new InputStreamReader(System.in));
        try {
            inputLine = reader.readLine();
        }
        catch(java.io.IOException exc) {
            System.out.println ("There was an error during reading: "
                                + exc.getMessage());
        }

        StringTokenizer tokenizer = new StringTokenizer(inputLine);

        if(tokenizer.hasMoreTokens())
            word1 = tokenizer.nextToken();      // Obtiene la primera palabra
        else
            word1 = null;
        if(tokenizer.hasMoreTokens())
            word2 = tokenizer.nextToken();      // Obtiene la segunda palabra
        else
            word2 = null;

        // note: Solo ignoramos lo que resta de la linea de entrada

        // Ahora checamos si la palabra es aceptada. Si eso pasa, se creará un comando
        // con eso.  Y si no , creamos un comando nulo (comando desconocido)

        if(commands.isCommand(word1))
            return new Command(word1, word2);
        else
            return new Command(null, word2);
    }

    /**
     * Imprime una lista de las palabras comando válidas.
     */
    public void showCommands()
    {
        commands.showAll();
    }
}
