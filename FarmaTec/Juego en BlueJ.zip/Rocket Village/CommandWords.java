/**
 * Esta clase es parte de Rocket Village.
 * Es una aventura de un detective famoso que buscara al culpable de un asesinato. . 
 *
 * Esta clase guarda una enumeración de todas las palabra comando conocidas para el juego.
 * Es usada para reconocer comandos que son tecleados. 
 *
 *
 * @author  Quiroz Bonilla Gabriel Alejandro
 * @version 1.0 
 */

public class CommandWords
{
    // Un arreglo constante que guarda todas las palabras comando válidas.
    private static final String[] validCommands = {
        "go", "quit", "help", "take", "drop", "items", "drink" 
    };

    /**
     * Constructor -  Inicilcia el CommandWords.
     */
    public CommandWords()
    {
        // No hará nda en este momento...
    }

    /**
     * Checa si el valor String es una palabra comando válida.
     * Regresa true si es, y false si no es.
     */
    public boolean isCommand(String aString)
    {
        for(int i = 0; i < validCommands.length; i++) {
            if(validCommands[i].equals(aString))
                return true;
        }
        // Si obtenemos esto, el valor string no había sido encontrado en los comandos. 
        return false;
    }

    /*
     * Imprime todos los comandos válidos a System.out.
     */
    public void showAll() 
    {
        for(int i = 0; i < validCommands.length; i++) {
            System.out.print(validCommands[i] + "  ");
        }
        System.out.println();
    }
}