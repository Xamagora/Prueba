/**
 *  * Esta clase es parte de Rocket Village.
 * Es una aventura de un detective famoso que buscará al culpable de un asesinato. 
 *
 * Esta clase guarda información acerca de un comando que fué ingresado por el usuario.
 * Un comando usualmente consiste en dos palabras: una palabra comando y una segunda
 * palabra ( por ejemplo, si el comando es "tomar mapa", entonces las dos palabras son 
 * obviamente "tomar" y "mapa"
 *
 * La forma en la que es usada: Los comandos ya son checados para ser palabras comando
 * validas. Si el usuario ingresa un coamndo inválido( una palabra que no es conocida)
 * entonces la palabra comando será "null".
 * 
 * Si el comando tien solo una palabras, entonces la segunda palabra es "null". 
 * 
 * @author  Quiroz Bonilla Gabriel Alejandro
 * @version 1.0 
 */

public class Command
{
    private String commandWord;
    private String secondWord;

    /**
     * Crea un objeto como comando. La primera y segunda palabra deben ser suplidas, pero
     * solo una ( o las dos) pueden ser null. La palabra comando debe ser null para 
     * inidcar que fue un comando que no esta reconocido por el juego. 
     */
    public Command(String firstWord, String secondWord)
    {
        commandWord = firstWord;
        this.secondWord = secondWord;
    }

    /**
     * Regresa la palabra comando ( la primera palabra) de este comando. si el
     * comando no fue entendido, el resultado es nulo
     */
    public String getCommandWord()
    {
        return commandWord;
    }

    /**
     * Regresa la segunda palabra coamdno de este comando. Regresa null si
     * no hubiera segunda palabra.
     */
    public String getSecondWord()
    {
        return secondWord;
    }

    /**
     * Regres true si el comando no fue entendido.
     */
    public boolean isUnknown()
    {
        return (commandWord == null);
    }

    /**
     * regresa true si el comando tiene segunda palabra.
     */
    public boolean hasSecondWord()
    {
        return (secondWord != null);
    }
}

